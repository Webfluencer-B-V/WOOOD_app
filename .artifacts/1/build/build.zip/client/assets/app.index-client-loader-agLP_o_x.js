async function n({serverLoader:a}){return await a()}export{n as clientLoader};
