async function n({serverAction:t}){return await t()}export{n as clientAction};
