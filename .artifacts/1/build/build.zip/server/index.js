import { s } from "./assets/worker-Bi9zfbKp.js";
export {
  s as default
};
