import { s } from "./assets/worker-DwqABaQ7.js";
export {
  s as default
};
